"""
Urban Dictionary Python (Unofficial)
Author : Abhimanyu Sharma
GitHub : https://github.com/0xN1nja
"""
from . urban_dictionary import UrbanDictionary
__version__ = "0.0.3 (Latest)"
__author__ = "Abhimanyu Sharma, https://github.com/0xN1nja"
