"""
Urban Dictionary Python (Unofficial)
Author : Abhimanyu Sharma
GitHub : https://github.com/0xN1nja
"""


class WordNotFound(Exception):
    """
    Raised When Query Is Invalid.
    """
    pass
